#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "functions.cpp"
#include <vector>

Camera myCamera;

std::vector<Light> G_l;
std::vector<Sphere> G_s;
std::vector<Plane> G_p;

void getVariable(FILE *fp, float *x) {
	int c, count, start;
	char buff[255];
	start = count = 0;
	while((c = fgetc(fp)) != EOF) {
		if (isdigit(c) || c == '.' || c == '-') {
			start = 1;
			buff[count++] = c;
		}
		else if (start == 1) {
			buff[count] = '\0';
			break;
		}
		else {
			//Waiting for input
		}
	}
	*x = atof(buff);
}

void getVector(FILE *fp, float *x, float *y, float *z) {
	getVariable(fp, x);
	getVariable(fp, y);
	getVariable(fp, z);
}

void getCamera(FILE *fp) {
	char temp[255];
	int count;
	float x, y, z;

	count = 0;

	while(fscanf(fp, "%s", temp) != EOF) {
		if(strcmp(temp, "location") == 0) {
			getVector(fp, &x, &y, &z);
			myCamera.set_location(x, y, z);
			count++;
		}
		else if(strcmp(temp, "up") == 0) {
			getVector(fp, &x, &y, &z);
			myCamera.set_up(x, y, z);
			count++;
		}
		else if(strcmp(temp, "right") == 0) {
			getVector(fp, &x, &y, &z);
			myCamera.set_right(x, y, z);
			count++;
		}
		else if(strcmp(temp, "look_at") == 0) {
			getVector(fp, &x, &y, &z);
			myCamera.set_lookat(x, y, z);
			count++;
		}
		if(count == 4) {
			return;
		}
	}
}

void getLSource(FILE *fp) {
	Light newLight;
	float x, y, z;
	getVector(fp, &x, &y, &z);
	newLight.set_location(x, y, z);
	getVector(fp, &x, &y, &z);
	newLight.set_color(x, y, z);
	
	G_l.push_back(newLight);
}

void getSphere(FILE *fp) {
	Sphere mySphere;
	char temp[255];
	int count;
	float x, y, z;
	getVector(fp, &x, &y, &z);
	mySphere.set_center(x, y, z);
	getVariable(fp, &x);
	mySphere.set_radius(x);

	count = 0;

	while(fscanf(fp, "%s", temp) != EOF) {
		puts(temp);
		if(strcmp(temp, "rgb") == 0) {
			getVector(fp, &x, &y, &z);
			mySphere.set_color(x, y, z);
			count++;
		}
		else if(strcmp(temp, "finish") == 0) {
			getVariable(fp, &x);
			mySphere.set_ambient(x);
			count++;
		}
		else if(strcmp(temp, "diffuse") == 0) {
			getVariable(fp, &x);
			mySphere.set_diffuse(x);
			count++;
		}
		else if(strcmp(temp, "translate") == 0) {
			getVector(fp, &x, &y, &z);
			mySphere.set_translate(x, y, z);
			count++;
		}
		if(count == 4) {
			G_s.push_back(mySphere);
			return;
		}
	}
}

void getPlane(FILE *fp) {
	Plane myPlane;
	float x, y, z;
	int count = 0;
	char temp[255];

	getVector(fp, &x, &y, &z);
	myPlane.set_normal(x, y, z);
	getVariable(fp, &x);
	myPlane.set_distance(x);

	while(fscanf(fp, "%s", temp) != EOF) {
		if(strcmp(temp, "rgb") == 0) {
			getVector(fp, &x, &y, &z);
			myPlane.set_color(x, y, z);
			count++;
		}
		else if(strcmp(temp, "{ambient") == 0) {
			getVariable(fp, &x);
			myPlane.set_ambient(x);
			count++;
		}
		else if(strcmp(temp, "diffuse") == 0) {
			getVariable(fp, &x);
			myPlane.set_diffuse(x);
			count++;
		}
		if(count == 3) {
			G_p.push_back(myPlane);
			return;
		}
	}
}

void printAll() {
	int i;
	printf("Camera\n");
	printf("Location: {%f, %f, %f}\n", myCamera.location.x, myCamera.location.y, myCamera.location.z);
	printf("Up: {%f, %f, %f}\n", myCamera.up.x, myCamera.up.y, myCamera.up.z);
	printf("Right: {%f, %f, %f}\n", myCamera.right.x, myCamera.right.y, myCamera.right.z);
	printf("Look at: {%f, %f, %f}\n", myCamera.lookat.x, myCamera.lookat.y, myCamera.lookat.z);
	for(i = 0; i < G_l.size(); i++) {
		printf("\nLight[%d]\n", i);
		printf("Location: {%f, %f, %f}\n", G_l.at(i).location.x, G_l.at(i).location.y, G_l.at(i).location.z);
		printf("Color: {%f, %f, %f}\n", G_l.at(i).color.x, G_l.at(i).color.y, G_l.at(i).color.z);
	}
	for(i = 0; i < G_p.size(); i++) {
		printf("\nPlane[%d]\n", i);
		printf("Normal: {%f, %f, %f}\n", G_p.at(i).normal.x, G_p.at(i).normal.y, G_p.at(i).normal.z);
		printf("Distance: %f\n", G_p.at(i).distance);
		printf("Color: {%f, %f, %f}\n", G_p.at(i).color.x, G_p.at(i).color.y, G_p.at(i).color.z);
		printf("Ambient: %f\n", G_p.at(i).ambient);
		printf("Diffuse: %f\n", G_p.at(i).diffuse);
	}
	
	for(i = 0; i < G_s.size(); i++) {
		printf("\nSphere[%d]\n", i);
		printf("Center: {%f, %f, %f}\n", G_s.at(i).center.x, G_s.at(i).center.y, G_s.at(i).center.z);
		printf("Radius: %f\n", G_s.at(i).radius);
		printf("Color: {%f, %f, %f}\n", G_s.at(i).color.x, G_s.at(i).color.y, G_s.at(i).color.z);
		printf("Ambient: %f\n", G_s.at(i).ambient);
		printf("Diffuse: %f\n", G_s.at(i).diffuse);
		printf("Translate: {%f, %f, %f}\n", G_s.at(i).translate.x, G_s.at(i).translate.y, G_s.at(i).translate.z);
	}
	
}

int main() {
	FILE *fp;
	char buff[255];

	fp = fopen("spheres.pov", "r");
	if(fp == NULL) {
		fprintf(stderr, "Error opening .pov file\n");
		exit(EXIT_FAILURE);
	}

	while(fscanf(fp, "%s", buff) != EOF) {
		
		if(strcmp(buff, "camera") == 0) {
			//Get Camera Code
			getCamera(fp);
		}
		
		else if(strcmp(buff, "light_source") == 0) {
			//Get Camera Code
			getLSource(fp);
		}
		else if(strcmp(buff, "sphere") == 0) {
			//Get Sphere Code
			getSphere(fp);
		}
		else if(strcmp(buff, "plane") == 0) {
			//Get Plane Code
			getPlane(fp);
		}
	
	}

	printAll();
	return 0;

}
